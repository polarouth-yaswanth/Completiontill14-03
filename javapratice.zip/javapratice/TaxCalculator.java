import java.util.Scanner;

public class TaxCalculator {
    public void calculateTax(int salary,String Country){
         try{
             Scanner s = new Scanner(System.in);
             System.out.println("Enter Employee salary:");
             salary = s.nextInt();
             System.out.println("Enter Employee Country:");
             Country = s.nextLine();
             if(Country!= Isindian){
                 System.out.println("CountryNotValidException")
             
             }
         }        



        }
}
