class Thread1 extends Thread {
    public void run() {
        int i = 0;
        while (i < 4) {
            System.out.println("IN T1");
            i++;
        }
    }
}

class Thread2 extends Thread {
    public void run() {
        int i = 0;
        while (i < 4) {
            System.out.println("IN T2");
            i++;
        }
    }
}

public class Threadp {
    public static void main(String[] args) {
        Thread1 t1 = new Thread1();
        Thread2 t2 = new Thread2();
        t1.start();
        t2.start();
    }
}
