interface Bicycle {
    public void speedUp(int i);

    public void slowDown(int d);
}

class Bicke implements Bicycle {
    int speed = 70;

    public void speedUp(int i) {
        speed = i;
        i = i + 10;
    }

    public void slowDown(int d) {
        speed = d;
        d = d - 12;
    }
}

public class InterfaceDemo {
    public static void main(String args[]) {
        Bicke b = new Bicke();
        System.out.println(b.speedUp());
        System.out.println(b.speedDown());
    }
}
