class Employee {
    private int id;
    private String name;
    static String ceo;

    static {
        ceo = "harry potter";
    }

    public void show() {
        System.out.println(ceo);
    }

    public void setId(int i) {
        id = i;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

public class Learninggands {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setId(1234);
        System.out.println(e.getId());
        e.setName("yaswanth");
        System.out.println(e.getName());
        e.show();
    }
}