import java.util.Scanner;

public class EXP {
    public static void main(String args[]) throws Exception {
        Scanner s = new Scanner(System.in);
        System.out.println("age pls");
        int age = s.nextInt();
        if (age < 5) {
            throw new Exception("Ur not allowd to watch");
        } else {
            System.out.println("ur allowed to watch");
        }
    }

}
