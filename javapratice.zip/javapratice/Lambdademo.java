class Cons {
    public void show() {
        System.out.println("num");
    }
}

public class Lambdademo {
    public static void main(String args[]) {
        Cons cik = new Cons() {
            public void show() {
                System.out.println("Hiiii");
            }
        };
        cik.show();
    }
}
