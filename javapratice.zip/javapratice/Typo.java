import java.util.Scanner;

class Typo {
    public static void main(String[] args) {
        int a, b;
        b = 40;
        Scanner s = new Scanner(System.in);
        a = s.nextInt();
        System.out.println("a value is:" + a);
        double ages;
        Scanner y = new Scanner(System.in);
        ages = y.nextInt();
        System.out.println("avg age:" + ages);
        s.close();
        /*
         * for (int i = 1; i < 6; i++) {
         * System.out.print("A value:");
         * System.out.println(a++);
         * System.out.println(a);
         * System.out.println(a--);
         * }
         */
    }
}