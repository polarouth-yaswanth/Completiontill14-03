import java.util.Scanner;
class A{
public static void main(String [] args){   /*arrays for strings*/
System.out.println("hello");
//return 0;
}
}