package com.springAop.pratice.shapes;

import java.util.jar.Attributes.Name;

public class Circle {
	private String name;

	public String getName() {
		return name;
		
	}

	public void setName(String name) {
		this.name = name;
		System.out.println("Circles setter method called");
	}
	
	public String setNameandReturnIt(String name) {
		this.name = name;
		System.out.println("String setter method called");
		return name;
	}
	

}
