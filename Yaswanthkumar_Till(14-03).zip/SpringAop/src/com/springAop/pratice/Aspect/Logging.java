package com.springAop.pratice.Aspect;


import org.aopalliance.intercept.Joinpoint;
import org.aspectj.apache.bcel.generic.ReturnaddressType;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;


@Aspect
public class Logging {
	
	/*@Before("allCircleMethods()")
	public void LoggingAdvice(JoinPoint joinpoint) {
		System.out.println(joinpoint.toString());
	}*/
	
	
	@AfterReturning(pointcut="args(name)",returning="returnString")
	public void arguMentStr(String name,String returnString) {
		System.out.println("A Method that takes string arguments has been called: " +name+ "The output value is "+returnString);
	}
	
	@AfterThrowing("args(name)")
	public void throwingAdvice(String name) {
		System.out.println("After throwing an error");
	}
	
	@Pointcut("execution(* get*())")
	public void allGetters() {} 
  
	@Pointcut("within(com.springAop.pratice.shapes.Circle)")
	public void allCircleMethods() {}
	
	
}
