package in.in.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import in.in.msg.Message;

public class TestMessage {
	//Variable declaration
	private Message m;
	private String Actual;
	private String Excepted;

	//Providing Data
	@BeforeEach
	public void setupData() {
		m = new Message();
		Excepted = "Welcome to AndhraPradesh";
		Actual = "";
	}

	@Test
	public void TestshowMsg() {

		Actual = m.showMsg("AndhraPradesh");
		assertEquals(Actual, Excepted);

	}
	
	@AfterEach
	public void cleanMsg() {
		Excepted = null;
		Actual = null;
		m = null;
	}


}
