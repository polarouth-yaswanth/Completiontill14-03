package in.in.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.*;

public class Testmsg {	
	@Test
	public void testA() {
		String Actual = "Hello";
		String Excepted = "Hellod";
		//Assertions.assertEquals(Actual,Excepted);
		//Assertions.assertEquals(Actual,Excepted,"This is not right");
		assertEquals(Actual,Excepted);
		
	}
}
