package com.spring.FactoryM;

import javax.naming.Context;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
   AbstractApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
   Atm a = context.getBean("atm",Atm.class);
   a.printBalanceInfo("70000");
   context.close();
  
	}
}
