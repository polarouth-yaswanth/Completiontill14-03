package com.depeninj.practice;

import org.springframework.context.ApplicationContext;


import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Exam {
  public static void main(String[] args) {
//	Student student = new Student();
 //	student.setstudentName("Apparao");
  //student.doNo();
    ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml"); 
	Student su = context.getBean("s0",Student.class);
	su.doNo();
	Student mars = context.getBean("s2",Student.class);
	mars.doNo();
	Student1 s1 = context.getBean("s1",Student1.class);
	s1.printData();
}
}
