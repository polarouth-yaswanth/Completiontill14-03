package com.coninj.pratice;

public class Student1 {
    private String student1Name;
    private int idNumber;
    
    
    public Student1(String student1Name, int idNumber) {
		this.student1Name = student1Name;
		this.idNumber = idNumber;
	}


	public void printData() {
    	System.out.println("Student name is: "+student1Name + " and id number is " +idNumber);
      
    }
    
}
