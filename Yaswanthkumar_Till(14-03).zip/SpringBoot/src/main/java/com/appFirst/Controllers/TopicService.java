package com.appFirst.Controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

@Service
public class TopicService {
 
	List<Topic> topics = new ArrayList<>(Arrays.asList(
			
			new Topic("123","Spring","This is a framework"),
			new Topic("124","Java","This is a Computer Lang"),
			new Topic("125","www","This is a web")	
			
			));
	public List<Topic> getallTopics(){
		return topics;
	}
	
	public Topic topic(String id) {
		return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	}

	public void topicAdd(Topic topic) {
		topics.add(topic);
		
	}

	public void topicUpdate(String id, Topic topic) {
		for(int i=0;i<topics.size();i++) {
			Topic t = topics.get(i);
			if(t.getId().equals(id)) {
				topics.set(i, topic);
				return;
			}
			
		}
		
	}

	public void delTopic(String id) {
	 topics.removeIf(t -> t.getId().equals(id));
	}
			
}
