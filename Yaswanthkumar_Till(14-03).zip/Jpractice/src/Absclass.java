class cc{
	public void nums(Number i) {
		System.out.println(i);
	}
}
public class Absclass {
	public static void main(String[] args) {
		cc bl=new cc();
		bl.nums(4);
	}
  
}
