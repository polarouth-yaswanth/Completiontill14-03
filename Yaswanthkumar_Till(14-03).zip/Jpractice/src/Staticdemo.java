class Emp {
	int eid;
	int salary;
	static String ceo;
	// if i want to update ceo without static only y will be updated
	static { // executes when we load a class
		ceo = "harrypotter";
	}

	public void show() {
		System.out.println(eid + ":" + salary + ":" + ceo);
	}

	public Emp() // executes we i load a obj
	{
		eid = 1;
		salary = 5000;
	}
}

public class Staticdemo {
	public static void main(String[] args) {

		Emp yaswanth = new Emp();

		Emp s = new Emp();

		s.show();

		yaswanth.show();
	}
}

//output will be first constructor then only static bcoz static starts after loading class