import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) {
		/*
		 * terinary operator int j=0,k=0; j=i>6?6:'f'; System.out.println(j);
		 * k=j>100?100:102; System.out.println(k);
		 */
		// Switch cases
		/*
		 * int i=5; switch(i) { case 1: System.out.println(1); break;//if i=1 without
		 * break every number prints 1,2,3,4,5 case 2: System.out.println(2); break;
		 * case 3: System.out.println(3); break; case 4: System.out.println(4); break;
		 * case 5: System.out.println("Hello 5"); break; //default:
		 * //System.out.println(55); }
		 */
		/*
		 * int i=1; do { System.out.println("2047"); i++; } while(i<=5); }
		 */
		/*
		 * for(int i=0;i<5;i++) { for(int j=4;j>i;j--) { //System.out.print(i+" ");
		 * System.out.print(j+" "); } System.out.println();
		 * 
		 * }
		 */
		/*
		 * for(int i=0;i<9;i++) { for(int j=1;j<i;j++) { System.out.print(+(char)i); }
		 * System.out.println(); }
		 */
		for (int i = 0; i < 22; i++) {
			if (i == 20) {
				break;
			}
			System.out.println("the value of i is" + i);
		}
	}
}
