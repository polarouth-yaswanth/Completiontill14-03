class Student {
	int id;
	String name;
}

public class Arraydemo {
	public static void main(String[] args) {
		/*
		 * int ary[]=new int[4]; ary[0]=1; ary[1]=5; ary[2]=4; ary[3]=3; for(int
		 * i=0;i<4;i++) { System.out.println(ary[i]);
		 */
		Student s1 = new Student();
		Student s2 = new Student();
		Student s3 = new Student();
		Student s4 = new Student();

		Student s[] = { s1, s2, s3, s4 };
		for (int i = 0; i < 4; i++) {
			System.out.println(s[i]);

		}
	}
}
