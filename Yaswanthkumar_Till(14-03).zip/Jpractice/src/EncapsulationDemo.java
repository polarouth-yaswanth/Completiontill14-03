//Encapsulation binds methods and data
/*class StudentDetails{
 private int rollno;
 private String name;
//getters and setters
public void setrollno(int r) {
	rollno = r;
}
public int getrollno() {
	return rollno;
}
public void setname(String name) {
	this.name=name;
}
public String getname() {
	return name;
}

}
public class EncapsulationDemo {

	public static void main(String[] args) {
		StudentDetails obj = new StudentDetails();
		obj.setrollno(4);
		obj.setname("yaswanth");
		System.out.println(obj.getrollno());
		System.out.println(obj.getname());
	}

}
*/


//NOTE: Generated getters and setters using source->getters and setters function (ALT+SHIFT+S)
class StudentDetails{
 private int rollno;
 private String name;
//getters and setters
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

}
public class EncapsulationDemo {

	public static void main(String[] args) {
		StudentDetails obj = new StudentDetails();
		obj.setRollno(4);
		obj.setName("yaswanth");
		System.out.println(obj.getRollno());
		System.out.println(obj.getName());
	}

}
