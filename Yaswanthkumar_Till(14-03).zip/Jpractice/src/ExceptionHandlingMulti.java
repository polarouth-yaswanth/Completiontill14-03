
/*public class ExceptionHandlingMulti {
	public static void main(String args[]) {
		try {
			int a[]=new int[6];
			a[7]=9;
			int i=9;
			int j=2;
			int k = i/j;
			System.out.println(k);
	     }
		catch(ArithmeticException|ArrayIndexOutOfBoundsException e) {
			System.err.println("F");
	     }
		/*catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("DD");*/
		 //}
	/*	catch(Exception e) {
			System.err.print("ERROR"); // its better to exception in the ending
		}
		finally {
			System.out.println("GOOD");
         }
	}
}*/



public class ExceptionHandlingMulti {
	public static void main(String args[]) {
		try {
			int i=8;
			int j=9;
			int k = i/j;
			if(k==0) 
				throw new YaswanthException("commer"); 
	  System.out.println(k);
		}       
		catch(Exception e) {
	  System.err.println("F "+ e.getMessage());
		}
}
}
