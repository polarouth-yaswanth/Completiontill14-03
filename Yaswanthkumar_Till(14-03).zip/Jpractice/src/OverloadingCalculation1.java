class OverloadingCalculation1 {
	public int sum(int... k) {
		int sumed = 0;
		for (int i : k) {
			sumed = sumed + i;
		}
		return sumed;
	}

	void sum(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	public static void main(String args[]) {
		OverloadingCalculation1 obj = new OverloadingCalculation1();
		obj.sum(20, 20);// now second int literal will be promoted to long
		obj.sum(20, 20, 20);

	}
}
