/*TYPES of Interfaces:
 * 1.Normal
 * 2.Single Abstract Method(1.7)-Functional Interface(1.8)-Lambda Expression-scala language
 * 3.Marker Interface
 */

/*interface Avx{
 public void show() {
	 
 }
}
public class Interfacestypesdemo {

	public static void main(String[] args) {
		Avx ob = new Avx() {
			public void show(){
				System.out.println("harisree will give me bj");
			}
		};
		ob.show();
		
	}

}
*/
/*interface Avx{
 public void show() {
	 
 }
}
public class Interfacestypesdemo {

	public static void main(String[] args) {
		Avx ob =()->System.out.println("H"); //lambda expression "()->"
		ob.show();
		
	}

}*/

//Default interface
/* In java 1.7 interfaces doesn't support defining methods but 1.8 it does by default keyword 
*/
@FunctionalInterface
/*interface Abx{   //can have many default methods but only one abstract method
	void abc();
	default void min() {
		System.out.println("noobs");
	}
}
class Abxc implements Abx{
	public void abc() {
		System.out.println("noo");
	}
	public void min() {
		System.out.println("hoo");
	}
}
public class Interfacestypesdemo{
	public static void main(String args[]) {
		Abx ob1 =new Abxc();
		ob1.abc();
		ob1.min();
	}
}*/



interface Abx{   //can have many default methods but only one abstract method
	void abc();
	default void min() {
		System.out.println("noobs");
	}
}
interface NewAbx{
	default void min() {
		System.out.println("hoo");
	}
}
class Abxc implements Abx,NewAbx{ //implemented multilevel interfaces
 	public void abc() {
		System.out.println("noo");
	}
	public void min() {
		System.out.println("hoo hoo");
	}
}

	
public class Interfacestypesdemo{
	public static void main(String args[]) {
		Abx ob1 =new Abxc();
		ob1.abc();
		ob1.min();
	}
}