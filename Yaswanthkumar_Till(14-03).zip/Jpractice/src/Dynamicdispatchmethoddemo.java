/*class Abcd{
	public void show() {
		System.out.println("B");
	}
}
class Bcde extends Abcd{
	public void show() {
		System.out.println("T");
	}
}
class Cdef extends Abcd{
	public void show() {
		System.out.println("P");
	}
}
public class Dynamicdispatchmethoddemo {
	public static void main(String[] args) {
       Abcd obj1 = new Bcde();  
       obj1.show();
       obj1 = new Cdef();   //Already referenced object is being used to create new constructor
       obj1.show();  //Here method is changing based on poly so it is dynamic dispatch method
	}

}*/

/* Abcd as reference Bcde as obj so the method in bcde must match with methods in abcd
 * or else error will occur example: config() method in bcde is present but not in abcd then
 * it is error becoz bcde parent class is abcd
 */
class Abcd{
	public void show() {
		System.out.println("B");
	}
}
class Bcde extends Abcd{
	public void show() {
		System.out.println("T");
	}
}
//Run-time polymorphism and Compile time polymorphism
public class Dynamicdispatchmethoddemo {
	public static void main(String[] args) {
       Abcd obj1 = new Bcde();   //Here it is run-time becoz which show() to run is based on polymorphism
       obj1.show();
	}
}





