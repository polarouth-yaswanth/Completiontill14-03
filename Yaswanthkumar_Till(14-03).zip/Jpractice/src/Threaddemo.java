
public class Threaddemo {
public static void main(String args[]) {
    int a[] = {1,2,3,4,6};
    for(int i=0;i<5;i++) {
    	a[i]=a[i]*5;
    	System.out.println(a[i]);
    }
}
}
