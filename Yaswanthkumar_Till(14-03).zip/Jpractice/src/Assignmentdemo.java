class TaxCalculator{
	public String employeecountry;
	public String employeename;
	public int employeesalary;
	public int taxAmount=0;
	public void calculateTax() {		
		if(employeecountry!="India" || employeename==NULL) {
  		  break;
  	  }
  	  else(){
  		  continue;
  	  }
  	  if(employeesalary>1000000 || employeecountry="India") {
  		taxAmount = empSal *8/100;
  		  
  	  }
  	if(employeesalary>50000 && <100000 || employeecountry="India") {
  		taxAmount = empSal *6/100;
  		  
  	  }
  	
  	if(employeesalary>30000 && <50000 || employeecountry="India") {
  		taxAmount = empSal *6/100;
  		  
  	  }
  	if(employeesalary>10000 && <30000 || employeecountry="India") {
  		taxAmount = empSal *5/100;
  		  
  	  }
	
}
public class Assignmentdemo {
	public static void main(String[] args) {
      TaxCalculator tc = new TaxCalculator();
      try {
    	  
    	  
      }
      
	}

}
