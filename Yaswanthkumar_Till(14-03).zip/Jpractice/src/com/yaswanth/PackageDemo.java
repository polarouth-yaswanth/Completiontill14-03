package com.yaswanth;
import com.yaswanth.test.Student;
public class PackageDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Student su = new Student();
      su.rollno();
      System.out.println(su.rollno());    //protected means next sub class package can access the data
	}                                      // private means only that class

}
