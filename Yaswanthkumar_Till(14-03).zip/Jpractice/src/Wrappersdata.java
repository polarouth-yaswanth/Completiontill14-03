
public class Wrappersdata {
 public static void main(String args[]) {
	 //int i=5; //primitive integer
	 //Integer ii  = new Integer(5); //reference variable//integer in this case is "WRAPPER CLASS"
	 //ln 5 : integer store in object
	 int i=5;
	 Integer ii  = new Integer(i);//boxing we kept primitive value in boxing
	 //to keep box value in variable
	 int j = ii.intValue(); //unboxing
	 System.out.println(j);
	 System.out.println(ii);
	 int f=6;
	 Integer ff = f; //auto boxing
	 System.out.println(ff);
	 int a=ff; //auto unboxing
	 System.out.println(a);
	 Float fx = 5.0f;
	 Float ffa = new Float(fx);
	 System.out.println(fx);
	 Float fa =fx.floatValue();
	 System.out.println(fa);
	 String  s = "2047";
	 int y = Integer.parseInt(s); //to convert str to int
	 System.out.println(y);
 }
}



//Primitive works much faster that wrapper classes