/*
public class ExceptionHandlingdemo {
	public static void main(String args[]) {
		try {
			int i=9/0;
	}
		catch(Exception e) {
			System.err.println("F");
	}
			System.out.println("GOOD");
    }
}
*/



public class ExceptionHandlingdemo {
	public static void main(String args[]) {
		try {
			int i=9;
			int j=0;
			int k=i/j;
			System.out.println(k);
	}
		catch(ArithmeticException e) {
			System.err.println("F");
	}
		finally {  //whatever result this msg prints
			System.out.println("GOOD");
    }
	}
}
