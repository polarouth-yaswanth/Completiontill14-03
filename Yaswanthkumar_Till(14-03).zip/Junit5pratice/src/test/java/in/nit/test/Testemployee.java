package in.nit.test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

//Test Method Order
//@TestMethodOrder(OrderAnnotation.class) //Not working
//  @TestMethodOrder(Alphanumeric.class) // Not working

//Test case which tests my code
public class Testemployee 
{ 
 //    @DisplayName("BEFOREALL")
	//@BeforeAll
	/*public static void set()
	{
		System.out.println("1");
	}*/
	
	
	//@BeforeEach     //Init,setup  ////Executing but no output
	@Test
	@Tag("1")
	public void setup()
	{
		System.out.println("Setup initilization");
	}
 
	//Test Method
	//@Order(3)
	 @Test
	 //@DisplayName("Hiiiii")
	 @Tag("2")
	public void testSave() 
	{
	 System.out.println("Deleting");
	}
	
	@AfterAll//Executing but no output
	@Tag("3")
	static void testSaved()       
	
	{
	 System.out.println(" Not Deleting");
	}
	
	
	//@Test
	//@Disabled
	//@Order(1)
	//public void testPin()
/*	{
		System.out.println("Saving");
	}
	
	@Test
	//@Order(2)      //Not working
	public void testDone()
	{
		System.out.println("Updating");
	}
	
	@AfterAll
	public static void sets() throws Exception
	{
		System.out.println("Eof");
	}

	@Test
    @RepeatedTest(value=3, name= "{displayName}- {currentRepetition}/{totalRepetitions}")
	@DisplayName("Multiple tests")
	/*public void testingzData(TestInfo i) {
		//System.out.println("HeLLO "+i.getTestClass().get().getName());
	    //System.out.println("Hiiii" +i.getTestMethod().get().getName());
	    System.out.println("Hello "+i.getDisplayName());
	}*/
	
}

