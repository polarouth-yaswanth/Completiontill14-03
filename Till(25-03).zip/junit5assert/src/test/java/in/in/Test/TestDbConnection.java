package in.in.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import in.in.msg.DbConnection;
import java.sql.Connection;

public class TestDbConnection {
    @Test
	public void TestgetCon() {
		DbConnection dbc = new DbConnection();
		Connection con = dbc.getCon();
		assertNotNull(con);
	}
	
	
	
	
}
