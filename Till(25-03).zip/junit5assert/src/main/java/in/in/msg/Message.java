package in.in.msg;

public class Message {
   public String showMsg(String name) {
	   return "Welcome to "+name;
   }
}
