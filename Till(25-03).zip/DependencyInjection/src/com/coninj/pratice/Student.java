package com.coninj.pratice;

public class Student {
     
	private String studentName;
	private int idNumber;
 
	
	public Student(String studentName, int idNumber) {
		this.studentName = studentName;
		this.idNumber = idNumber;
	}


	public void doNo() {
		System.out.println("Student name is: " +studentName + " and id number is " +idNumber);
	}
	
	
	
}
