package com.springAop.pratice;


import org.springframework.context.ApplicationContext; 
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springAop.pratice.service.Shapeservice;
import com.springAop.pratice.shapes.Circle;

public class AopMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Shapeservice ss = context.getBean("shapeService",Shapeservice.class);
		ss.getCircle().setNameandReturnIt("AfterReturn Advice it is");
	}

}
