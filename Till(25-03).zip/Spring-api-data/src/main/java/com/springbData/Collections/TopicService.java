package com.springbData.Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

@Service
public class TopicService {
	
	@Autowired
	private TopicRepository topicRepository;
 
	/*
	 * List<Topic> topics = new ArrayList<>(Arrays.asList(
	 * 
	 * new Topic("123","Spring","This is a framework"), new
	 * Topic("124","Java","This is a Computer Lang"), new
	 * Topic("125","www","This is a web")
	 * 
	 * ));
	 */
	public List<Topic> getallTopics(){
		List<Topic> topics = new ArrayList<>();
		topicRepository.findAll().forEach(topics::add);
		return topics;
	}
	
	public Topic topic(String id) {
		//return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	      return topicRepository.findById(id).orElse(null);
	}

	public void topicAdd(Topic topic) {
		topicRepository.save(topic);
		
	}

	public void topicUpdate(String id, Topic topic) {
		/*for(int i=0;i<topics.size();i++) {
			Topic t = topics.get(i);
			if(t.getId().equals(id)) {
				topics.set(i, topic);
				return; */
		     topicRepository.save(topic);
		
			}
		

	public void delTopic(String id) {
	 //topics.removeIf(t -> t.getId().equals(id));
        topicRepository.deleteById(id);
	}
			
}
