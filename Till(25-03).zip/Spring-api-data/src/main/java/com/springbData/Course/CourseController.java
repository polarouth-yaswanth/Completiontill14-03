package com.springbData.Course;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springbData.Collections.Topic;

@RestController
public class CourseController {
	
    @Autowired
	private CourseService courseservice;
    
    @RequestMapping("/topics/{id}/courses")
    public List<Course> getAllCourses(@PathVariable String id){
    	return courseservice.getAllCourses(id);
    }
    
    @RequestMapping("/topics/{topicId}/courses/{id}")
    public Course getcourse(@PathVariable String id) {
      return courseservice.getcourse(id);   
    }
    
    
    @RequestMapping(method = RequestMethod.POST, value="/topics/{topicId}/courses")
    public void courseAdd(@RequestBody Course course,@PathVariable String topicId) {
    	course.setTopic(new Topic(topicId,"",""));
    	courseservice.courseAdd(course);
    }
    
    @RequestMapping(method = RequestMethod.PUT, value="/topics/{topicId}/courses/{id}")
    public void courseUpdate(@RequestBody Course course,@PathVariable String topicId,@PathVariable String id) {
    	course.setTopic(new Topic(topicId,"",""));
    	courseservice.courseUpdate(course);
    }
    
    @RequestMapping(method=RequestMethod.DELETE, value="/topics/{topicId}/courses/{id}")
    public void delCourse(@PathVariable String id) {
    	courseservice.delCourse(id);   
    }
    
    
    
    
    
    
    
}