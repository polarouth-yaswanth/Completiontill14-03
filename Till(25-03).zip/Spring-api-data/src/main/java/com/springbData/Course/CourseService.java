package com.springbData.Course;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CourseService {
	
	@Autowired
	private CourseRepository courseRepository;
 
	/*
	 * List<Topic> topics = new ArrayList<>(Arrays.asList(
	 * 
	 * new Topic("123","Spring","This is a framework"), new
	 * Topic("124","Java","This is a Computer Lang"), new
	 * Topic("125","www","This is a web")
	 * 
	 * ));
	 */
	public List<Course> getAllCourses(String iD){
		List<Course> courses = new ArrayList<>();
		courseRepository.findByTopicId(iD).forEach(courses::add);
		return courses;
	}
	
	public Course getcourse(String id) {
		//return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	      return courseRepository.findById(id).orElse(null);
	}

	public void courseAdd(Course course) {
		courseRepository.save(course);
		
	}

	public void courseUpdate(Course course) {
		/*for(int i=0;i<topics.size();i++) {
			Topic t = topics.get(i);
			if(t.getId().equals(id)) {
				topics.set(i, topic);
				return; */
				courseRepository.save(course);
		
			}
		

	public void delCourse(String id) {
	 //topics.removeIf(t -> t.getId().equals(id));
		courseRepository.deleteById(id);
	}
			
}
