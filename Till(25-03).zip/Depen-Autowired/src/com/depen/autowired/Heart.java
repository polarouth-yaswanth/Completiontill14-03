package com.depen.autowired;

public class Heart {
  public void pumpingBlood() 
  {
	  System.out.println("Bpm is good!");
	  System.out.print("so good ");;
  }
}
