
package com.depen.autowired;

public class Eyes {
     public void seeingWorld() {
    	 System.out.println("Eyes is used for seeing natures beauty");
     }
}
