package com.depen.autowired;

public class Human
{
	private Heart heart;
	private Eyes eyes;
	
	
	
	
    
	public void setEyes(Eyes eyes) {
		this.eyes = eyes;
	}



	public void setHeart(Heart heart) {
		this.heart = heart;
	}
	
	
	
	public void conditionHuman() {
			
	  // heart.pumpingBlood();
	   eyes.seeingWorld();
		}
}
