package com.depobinj.in;

import org.springframework.core.env.SystemEnvironmentPropertySource;

public class Scicheat implements Cheat {

	public void cheat() {
	   System.out.println("...Science script started........");
	}
}
