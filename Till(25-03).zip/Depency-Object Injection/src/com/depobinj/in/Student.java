package com.depobinj.in;

public class Student{
 
	private Cheat cheat;

	public void setCheat(Cheat cheat) {
		this.cheat = cheat;
	}
	
	public void Cheating() {
		cheat.cheat();
	}
	
	
	
}
