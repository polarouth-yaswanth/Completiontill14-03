package com.depobinj.in;

public class Mathcheat implements Cheat {

	public void cheat() {
		System.out.println("...............I started cheatsheet......");
	}
	
}
