/*class ABC {
	public void show() {
		System.out.println("a");
	}
}
class DEF extends ABC{
	@Override
	public void show() {
		System.out.println("b");
	}
}

public class MethodOverriding {
 public static void main(String[] args) {
	 DEF obj1 = new DEF();
	 obj1.show();
 }
}

//Notes
  Child class show() method overrides parent class show() method */

class ABC {
	public void show() {
		System.out.println("a");
	}
}
class DEF extends ABC{
	@Override
	public void show() {
		super.show();
		System.out.println("b");
	}
}

public class MethodOverriding {
 public static void main(String[] args) {
	 DEF obj1 = new DEF();
	 obj1.show();
 }
}

//Notes
//changes new method introduced super.show()
//super is used to represent parent class objects