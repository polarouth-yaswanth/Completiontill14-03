//SINGLE LEVEL INHERITANCE
/*class Calcu{
 public int add(int i,int j) {
	 return i+j;
 }
}
class Calcua extends Calcu{
	public int sub(int i,int j) {
		return i-j;
	}
}
public class InheritanceoopsDemo {
 public static void main(String[] args) {
   Calcu obj= new Calcu();
   Calcua obj1= new Calcua();
   int addition=obj.add(4, 5);
   int subtraction=obj1.sub(5, 4);
   System.out.println(addition);
   System.out.println(subtraction);
 }
}
*/
// MULTI LEVEL INHERITANCE
class Calcu {
	public int add(int i, int j) {
		return i + j;
	}
}

class Calcua extends Calcu {
	public int sub(int i, int j) {
		return i - j;
	}
}

class Calcual extends Calcua {
	public int div(int i, int j) {
		return i / j;
	}
}

public class InheritanceoopsDemo {
	public static void main(String[] args) {
		Calcual obj2 = new Calcual();
		int addition = obj2.add(4, 5);
		int subtraction = obj2.sub(5, 4);
		int division = obj2.div(50, 4);
		System.out.println(addition);
		System.out.println(subtraction);
		System.out.println(division);
	}
}

//notes
/*
 * Is-a relationship for single level inheritance Has-a relationship when one
 * class access the features of another class Example: Main class uses the
 * features of class calcu
 */
