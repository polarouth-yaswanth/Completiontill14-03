/*class A{
  public A()
  {
	  System.out.println("in A");
  }
  public A(int i) {
	  System.out.println("in A int");
  }
}
class B extends A
{
	public B() 
	{
		System.out.println("in B");
	}
	public B(int i) {
		System.out.println("IN B int");
	}
}
public class SuperclassDemo {
  
	public static void main(String[] args) {
     B ob2 = new B(4);
	}

}

*/
//Notes1
/* WHENEVER WE CALL CONSTRUCTOR OVERLOADING WITH INHERITANCE THE SUB CLASS
 * CALLS THE DEFAULT CONSTRUCTOR OF SUPER CLASS NOT PARAMETERIZED CONSTRUCTOR
 * SEE ABOVE EXAMPLE OBJECT ob2 DISPLAYS RESULT AS "IN B INT AND IN A" BUT WE 
 * EXCEPT TO SHOW "IN a INT".
 */

class A {
	public A() {
		System.out.println("in A");
	}

	public A(int i) {
		System.out.println("in A int");
	}
}

class B extends A {
	public B() {
		super();
		System.out.println("in B");
	}

	public B(int i) {
		super();
		System.out.println("IN B int");
	}
}

public class SuperclassDemo {

	public static void main(String[] args) {
		B ob2 = new B(4);
	}

}

//Notes2 EXPLAINATION FOR NOTES1
/*
 * By default we have super method in constructor.if we parameters to super
 * method then we can get the result as parametrized constructor We get default
 * constructor because of super() method
 *
 * 
 * 
 */
