/*class Casio{
public void add(int num,int bum) {
	System.out.print(num+bum);
}
public void add(int num,int bum,int gum,int kim) {
	System.out.println(num+bum+gum+kim);
}
public void add(double num,double bum) {
	System.out.println(num+bum);
}
}
public class MethodoverLoadingpratice {
   public static void main(String [] args) {
       Casio obj = new Casio();
       obj.add(5, 7);
       obj.add(5,7,8,9);
       obj.add(4.5, 9.5);
   }
}*/
//CONSTRUCTOR overloading	   
class Casio {
	int i;
	int j;
	String operation;

	public Casio() {
		i = 0;
	}

	public Casio(int num1) {
		i = num1;
	}

	public Casio(int num1, int num2) {
		i = num1;
		j = num2;
	}

	public Casio(int num1, int num2, String op) {
		i = num1;
		j = num2;
		operation = op;
	}
}

class MethodoverLoadingpratice {
	public static void main(String[] args) {
		Casio obj = new Casio(4, 5, "Yaswanth");
		System.out.println(obj.i);
		System.out.println(obj.j);
		System.out.println(obj.operation);

	}
}
