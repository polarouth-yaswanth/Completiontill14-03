interface apie{
	final int m = 8;
	void abc();         //if we insert variable inside interface it becomes constant 
	static void show() {
		System.out.println("Hii");
	}
}
class Abc implements apie{
	public void abc() {
		System.out.println(m);
	}
}
public class StaticinterfaceDemo {
 public static void main(String [] args) {
	 apie.show();
 }
}
