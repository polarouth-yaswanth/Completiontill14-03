/*
 * without static (member class)
 * inner class
 * static class
 * anonymous class
 * 
 * 
 * 
 * 
 * 
 * 
 */

class Outer {
	public static void display() {
		System.out.println("iu");
	}

	static class Inside {
		public static void show() {
			System.out.println("HIiiii");
		}
	}
}

public class Innerclass {
	public static void main(String[] args) {
		Outer obj = new Outer();
		Outer.Inside obj1 = obj.new Inside(); // outerclass has to be specified because of scope
		obj.display();
		obj1.show();

	}
}
