/*abstract class Mobiles{
	public abstract void Model();
}

class Iphone extends Mobiles{
	public void Model() {
		System.out.println("model is iphone 14 pro max");
	}
}
class Oneplus extends Mobiles{
	public void Model() {
		System.out.println("model is Oneplus 10 pro");
	}
	
}
class Moto{
	public void Charger(Mobiles mb) {
		mb.Model();
	}
	
}

public class InterfacesDemo{
	public static void main(String[] args) {
		Moto m = new Moto();
	    Mobiles ip = new Iphone();
		Mobiles md = new Oneplus();
		m.Charger(md);
	}
}*/

//Note:In java multiple inheritance is not possible so we can use interfaces with "implements" keyword
//Interfaces have only abstract methods but not normal methods
//extends classname implements classname (for multiple implementations


/*abstract class Mobiles{
	public abstract void Model();
}

class Iphone extends Mobiles{
	public void Model() {
		System.out.println("model is iphone 14 pro max");
	}
}
class Oneplus extends Mobiles{
	public void Model() {
		System.out.println("model is Oneplus 10 pro");
	}
	
}
class Moto{
	public void Charger(Mobiles mb) {
		mb.Model();
	}
	
}

public class InterfacesDemo{
	public static void main(String[] args) {
		Moto m = new Moto();
	    Mobiles ip = new Iphone();
		Mobiles md = new Oneplus();
		m.Charger(md);
	}
}*/


interface Abc{
	public void show();
}
class Bcf implements Abc{
	public void show() {
		System.out.println("Showws");
	}
	
}

public class InterfacesDemo{
	public static void main(String args[]) {
      Abc obj1 = new Bcf();
      obj1.show();
	}
}