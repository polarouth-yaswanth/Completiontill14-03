abstract class Aliens{
	public abstract void Male() {    //abstract class returns nothing used for future use
 		                            //if method is abstract class should be astract
	}
	public void Female() {
		
	}
}
class Humans extends Aliens{ //Concrete class
	public void male(){
		
	}
}
public class Abstractdemo {
 Aliens obj = new Humans();
}
