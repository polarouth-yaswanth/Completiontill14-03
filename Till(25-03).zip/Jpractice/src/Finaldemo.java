//Final keyboard for variable
/*class Fin{
	final int DAY; //const should be in caps
	public Fin() {
		DAY=1000;
		DAY=1;
		
	}
}
public class Finaldemo {
	public static void main(String [] args) {
  Fin obj=new Fin();
  System.out.println(obj.DAY);
}
}
*/
//Final keyword for class

/*final class Fin{
	public void Msg() {
		System.out.println("HIII");
	}
}
class Fun extends Fin{
	
}
public class Finaldemo {
	public static void main(String [] args) {
  Fun obj=new Fun();
  obj.Msg();
}
}*/
//final keyword for method
/*class Fin{
	public final void Msg() {
		System.out.println("HIII");
	}
}
class Fun extends Fin{
  public void Msg() {
	  System.out.println("B");
  }
}
public class Finaldemo {
	public static void main(String [] args) {
  Fun obj=new Fun();
  obj.Msg();
}
}
*/ //shows warning msg
