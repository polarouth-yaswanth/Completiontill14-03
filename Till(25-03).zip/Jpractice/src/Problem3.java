/*class Calc{ //class init
	int num1;
	int num2;
	int result=0;
public void perform() {
	result= num1+num2;
}
}
public class Problem3 {

	public static void main(String[] args) {
		
      Calc a = new Calc(); //obj init //Also constructor
      //To create obj (A obj= new A())
      a.num1=20; //accessing variable from another class Here a is reference of object
      a.num2=47;
      a.perform();
      System.out.print(a.result);

	}

}*/
/*class Calc{ //class init
	int num1;
	int num2;
	int result=0;
	public Calc(){
		num1=5;
		num2=10;
	}
	public Calc(int n) {
		num1=n;
		num2=n;
	}
	public Calc(int f,double k) {
		num1=f;
		num2=(int)k;
	}
}
public class Problem3 {

	public static void main(String[] args) {
		
      Calc a = new Calc(9,4.5); //obj init //Also constructor
      //To create obj (A obj= new A())
      System.out.println(a.num1);
      System.out.println(a.num2);
	}

}*/
/*class Calc{ //class init
	int num1;
	int num2;
	int result=0;
	public Calc(int no1,int no2){
		num1=no1;  //num1 is obj variable,no1 is local variable
		num2=no2;
	}
}
public class Problem3 {

	public static void main(String[] args) {
		
      Calc a = new Calc(9,4); //obj init //Also constructor
      //To create obj (A obj= new A())
      System.out.println(a.num1);
      System.out.println(a.num2);
	}

}*/
/*class Calc{ //class init
	int num1;
	int num2;
	int result=0;
	public Calc(int num1,int num2){
		num1=num1;//now its refered as same classes so answer is zero
		num2=num2;
	}
}
public class Problem3 {

	public static void main(String[] args) {
		
      Calc a = new Calc(9,4); //obj init //Also constructor
      //To create obj (A obj= new A())
      System.out.println(a.num1);
      System.out.println(a.num2);
	}

}*/
class Calc { // class init
	int num1;
	int num2;
	int result = 0;

	public Calc(int num1, int num2) {
		this.num1 = num1;// now its refered as same classes so answer is zero
		this.num2 = num2;// so "this" keyword is used which represents current object
	}
}

public class Problem3 {

	public static void main(String[] args) {

		Calc a = new Calc(9, 4); // obj init //Also constructor
		// To create obj (A obj= new A())
		System.out.println(a.num1);
		System.out.println(a.num2);
	}

}
