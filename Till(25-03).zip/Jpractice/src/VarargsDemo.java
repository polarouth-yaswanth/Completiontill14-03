/*class Calculator{
	public int add(int ... s) {
		int addition=0;
		for(int i:s) {
			addition = addition + i;
		}
		return addition;
	}
}

class VarargsDemo{
	public static void main(String [] args) {
		Calculator obj = new Calculator();
		System.out.println(obj.add(4,5,6,7,8,9,9));
	}
}*/

class C {
	public int add(int... s) {
		int sum = 0;
		for (int i : s) {
			sum = sum + i;
		}
		return sum;
	}
}

class Apple {
	public static void main(String[] args) {
		C obj = new C();
		System.out.println(obj.add(2, 3, 4, 6, 7, 8));
	}
}