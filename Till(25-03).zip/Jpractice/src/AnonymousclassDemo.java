class Appl{
	public void show() {
		System.out.println("big bog");
	}
}
public class AnonymousclassDemo {
	public static void main(String [] args) {
    Appl obj=new Appl() 
    {
    	public void show()
    	{
    		System.out.println("tik tok");                     //anonymous class
    	}
    };
    obj.show();
}
}


/*interface Appl{public void show();};
public class AnonymousclassDemo {
	public static void main(String [] args) {
    Appl obj=new Appl() 
    {
    	public void show()
    	{
    		System.out.println("tik tok");                     //anonymous class
    	}
    };
    obj.show();
    
}
}*/
//can implement interfaces using anonymous class
