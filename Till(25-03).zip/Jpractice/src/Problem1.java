import java.util.Scanner;

public class Problem1 {
	public static void main(String[] args) {
		int x;
		Scanner s = new Scanner(System.in);
		x = s.nextInt();
		System.out.println("Enter x value:" + x);
		if (x % 2 == 0) {
			System.out.print(true);
			System.out.println("Even number it is");
		} else {
			System.out.println(false);
			System.out.println("odd number it is");
		}
	}
}
