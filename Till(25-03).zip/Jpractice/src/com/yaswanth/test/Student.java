package com.yaswanth.test;

public class Student {
     public int rollno=4;
 
	}

