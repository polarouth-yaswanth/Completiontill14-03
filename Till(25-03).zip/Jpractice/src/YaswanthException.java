
public class YaswanthException extends Exception {
  public YaswanthException(String s) {
	  super(s);
  }
}
