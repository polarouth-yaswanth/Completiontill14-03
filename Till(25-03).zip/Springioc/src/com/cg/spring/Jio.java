package com.cg.spring;

public class Jio implements Sim {
	
	  public void Calling() {
	    	 System.out.println("I am calling my love through jio");
	}
	     public void Data() {
	    	 System.out.println("I am draining my data by lending hotspot");
	     }

}
